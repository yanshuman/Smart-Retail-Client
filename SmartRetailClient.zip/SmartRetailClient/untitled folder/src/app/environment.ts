export const environment =
{
    production : false,
    apiendpoint : 'https://smartretailserver.azurewebsites.net'
}