import { Wishlist } from './wishlist.model';

describe('Wishlist', () => {
  it('should create an instance', () => {
    //expect(new Wishlist()).toBeTruthy();
  });
});
