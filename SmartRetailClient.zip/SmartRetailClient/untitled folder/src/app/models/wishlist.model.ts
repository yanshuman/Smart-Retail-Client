

export interface Wishlist {

  wishlistID: number;
  dateAdded: Date;
  productID: number;
  customerID: number;
 
  
}
