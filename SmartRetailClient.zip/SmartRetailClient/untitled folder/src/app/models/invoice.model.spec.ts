// import { Invoice } from './invoice.model';

// describe('Invoice', () => {
//   it('should create an instance', () => {
//     expect(new Invoice()).toBeTruthy();
//   });
// });
