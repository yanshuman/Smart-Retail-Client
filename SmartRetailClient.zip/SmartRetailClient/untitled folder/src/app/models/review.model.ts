export interface Review
{
    rating : number,
    comment : string,
    reviewDate : Date,
    productID : number,
    customername : string
}