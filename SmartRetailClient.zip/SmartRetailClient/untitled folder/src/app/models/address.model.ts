

export interface Address
{
  name : string,
  mobile : number,
  email : string,
  street: string,
  city: string,
  state: string,
  country: string,
  zip: string,

}