export interface Category {

    categoryID: number;
    name: string;
    imageUrl : string;

  
    
    
    
  }