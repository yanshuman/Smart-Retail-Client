// import { Address } from './address.model';

// describe('Address', () => {
//   it('should create an instance', () => {
//     expect(new Address()).toBeTruthy();
//   });
// });
