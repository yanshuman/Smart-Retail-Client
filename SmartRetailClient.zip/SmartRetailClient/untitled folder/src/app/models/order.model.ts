export interface Order
{
    orderID: number,
    orderDate : Date,
    amount : number
}